BEGIN
	BEGIN TRANSACTION

	DECLARE @originalTuition DECIMAL
	SET @originalTuition = (SELECT Tuition_Fee FROM Students
							WHERE S_ID = 50)


	DECLARE @discount DECIMAL
	SET @discount = @originalTuition * 0.15


	DECLARE @discountedTuition DECIMAL
	SET @discountedTuition = @originalTuition - @discount

	UPDATE Students
	SET Tuition_Fee = @discountedTuition
	WHERE S_ID = 50


	UPDATE Students
	SET Balance = @discountedTuition
	WHERE S_ID = 50

	UPDATE Students
	SET Balance = Balance - @discountedTuition
	WHERE S_ID = 50

	SELECT * FROM Students


	DECLARE @NewBalance DECIMAL
	SET @NewBalance = (SELECT Tuition_Fee FROM Students
						WHERE S_ID = 50)

	IF @NewBalance > 0
		BEGIN
			SAVE TRANSACTION StudentDiscountTuition
		END
	ELSE IF @NewBalance < 0
		BEGIN
			ROLLBACK TRANSACTION StudentDiscountedTuition
		END

END